<?php
/**
 * =====================================================================
 *  expedicion.php · Forja de Héroes II · La party y la mazmorra
 * =====================================================================
 *  0613 DWES · UD3 · Código embebido I
 *
 *  Genera en cada petición el informe completo de la expedición: estado
 *  de la party, diario sala a sala, combate contra el jefe por rondas,
 *  inventario final y mapa. PHP no recuerda nada entre peticiones, así
 *  que cada recarga recalcula todo desde cero a partir de los datos.
 *
 *  @author  TU NOMBRE Y APELLIDOS
 *  @variant A  (debe coincidir con VARIANTE en inc/reglas.php)
 *  @version UD3
 *
 *  Estructura: 1) carga · 2) cálculos (sin HTML) · 3) presentación.
 */

declare(strict_types=1);

// =====================================================================
// R1 · CARGA
// =====================================================================
// Reglas comunes primero: definen VARIANTE, que decide qué fichero de
// datos se carga a continuación. require_once evita cargarlos dos veces.
require_once __DIR__ . '/inc/reglas.php';
require_once __DIR__ . '/inc/datos-' . VARIANTE . '.php';

// =====================================================================
// R2 · LA PARTY
// =====================================================================
// Se recorre por índice ($i) para poder guardar los datos calculados en
// la propia matriz; con $heroe solo se modificaría una copia.
foreach ($party as $i => $heroe) {
    $nivel = intdiv($heroe['xp'], XP_POR_NIVEL) + 1;

    // R3 · Daño con match SIN default: una clase desconocida debe fallar
    // con UnhandledMatchError en lugar de inventarse un valor. Va antes
    // que MULT_VIDA para que ese sea el primer error que se vea.
    $danio = (float) match ($heroe['clase']) {
        'Guerrera'  => $heroe['fuerza'] ** 2 / 10 + $nivel * 2,
        'Hechicero' => $heroe['inteligencia'] * 3 + $nivel ** 2 / 4,
        'Pícara'    => $heroe['destreza'] * 2 + $nivel ** 1.5,
        'Clérigo'   => ($heroe['inteligencia'] + $heroe['constitucion']) * 1.5 + $nivel,
    };

    $vidaMax = VIDA_BASE + $heroe['constitucion'] * $nivel * MULT_VIDA[$heroe['clase']];
    $pctVida = $heroe['vida'] / $vidaMax * 100;

    // R3 · Estado: las condiciones se evalúan en orden, de la más grave a
    // la más leve, por eso basta con comparar contra un solo umbral cada vez.
    if ($heroe['vida'] <= 0) {
        $estado = 'K.O.';
    } elseif ($pctVida < 35) {
        $estado = 'En peligro';
    } elseif ($pctVida < 70) {
        $estado = 'Herido';
    } else {
        $estado = 'En pie';
    }

    // R3 · Posición: casos agrupados (sin break entre ellos) para que
    // Guerrera y Clérigo compartan el mismo resultado.
    switch ($heroe['clase']) {
        case 'Guerrera':
        case 'Clérigo':
            $posicion = 'Primera línea';
            break;
        case 'Pícara':
            $posicion = 'Flanco';
            break;
        case 'Hechicero':
            $posicion = 'Retaguardia';
            break;
        default:
            $posicion = 'Reserva';
    }

    // Barra de 20 bloques con for (str_repeat está prohibido): los primeros
    // $bloquesLlenos se pintan llenos y el resto vacíos.
    $bloquesLlenos = (int) round($pctVida / 100 * BLOQUES_BARRA);
    $barra = '';
    for ($b = 0; $b < BLOQUES_BARRA; $b++) {
        if ($b < $bloquesLlenos) {
            $barra .= '█';
        } else {
            $barra .= '░';
        }
    }

    // Todo se guarda en la matriz para que la presentación solo recorra.
    $party[$i]['nivel']    = $nivel;
    $party[$i]['vidaMax']  = $vidaMax;
    $party[$i]['pctVida']  = $pctVida;
    $party[$i]['danio']    = $danio;
    $party[$i]['poder']    = (int) round($danio * $nivel);
    $party[$i]['estado']   = $estado;
    $party[$i]['posicion'] = $posicion;
    $party[$i]['barra']    = $barra;
}

// Totales de la party: array_column saca una columna de la matriz y
// array_sum la suma, sin necesidad de otro bucle.
$vidaParty    = array_sum(array_column($party, 'vida'));
$vidaMaxParty = array_sum(array_column($party, 'vidaMax'));
$poderParty   = array_sum(array_column($party, 'poder'));
$nivelMedio   = array_sum(array_column($party, 'nivel')) / count($party);

// Segundo recorrido: solo cuentan los héroes que pueden luchar. continue
// salta al siguiente héroe sin ejecutar el resto del cuerpo.
$danioParty    = 0.0;
$heroesActivos = 0;
$lider         = null;   # null = todavía no hay líder (ni héroes activos)
foreach ($party as $heroe) {
    if ($heroe['estado'] === 'K.O.') {
        continue;
    }
    $danioParty += $heroe['danio'];
    $heroesActivos++;
    // El primero que llega es líder por defecto; después gana quien tenga
    // más poder (con empate se queda el anterior).
    if ($lider === null || $heroe['poder'] > $lider['poder']) {
        $lider = $heroe;
    }
}
$nombreLider = '—';
if ($lider !== null) {
    $nombreLider = $lider['nombre'];
}

// El modo estricto de in_array (tercer argumento true) compara también el
// tipo, así que 'Pícara' no puede coincidir con valores raros por coerción.
$clases      = array_column($party, 'clase');
$hayPicara   = in_array('Pícara', $clases, true);
$hayClerigo  = in_array('Clérigo', $clases, true);

// =====================================================================
// R4 · LA EXPEDICIÓN (sala a sala)
// =====================================================================
$oro             = $oroInicial;
$xpGanada        = 0;
$diario          = [];
$salasExploradas = 0;

foreach ($salas as $n => $sala) {
    $numSala = $n + 1;   // los índices empiezan en 0; las salas, en 1
    $salasExploradas++;
    $etiqueta = 'Sala ' . $numSala . ' · ' . $sala['nombre'];

    switch ($sala['tipo']) {
        case 'vacía':
            $diario[] = $etiqueta . ': vacía, la party sigue avanzando.';
            // Dentro de un switch, "continue" actúa como "break" y solo
            // saldría del switch. continue 2 sube dos niveles: salta a la
            // siguiente iteración del foreach (y se salta el chequeo de vida).
            continue 2;

        case 'trampa':
            if ($hayPicara) {
                $diario[] = $etiqueta . ': trampa evitada gracias a la Pícara.';
            } else {
                $vidaParty -= $sala['valor'];
                $diario[] = $etiqueta . ': ¡trampa! −' . $sala['valor'] . ' de vida.';
            }
            break;

        case 'combate':
            // Un combate cuesta la cuarta parte de su valor en vida y
            // da ese valor completo en experiencia.
            $dano = intdiv($sala['valor'], 4);
            $vidaParty -= $dano;
            $xpGanada  += $sala['valor'];
            $diario[] = $etiqueta . ': combate, −' . $dano . ' de vida y +' . $sala['valor'] . ' XP.';
            break;

        case 'tesoro':
            $oro += $sala['valor'];
            $linea = $etiqueta . ': +' . number_format((float) $sala['valor'], 0, ',', '.') . ' mo';
            // Solo algunas salas traen objeto. El ?? 0 cubre el caso de un
            // objeto que aún no estaba en el inventario (evita un Warning).
            if (isset($sala['objeto'])) {
                $inventario[$sala['objeto']] = ($inventario[$sala['objeto']] ?? 0) + 1;
                $linea .= ' y «' . $sala['objeto'] . '»';
            }
            $diario[] = $linea . '.';
            break;

        case 'descanso':
            // Se cura el doble con Clérigo, pero nunca por encima del máximo.
            // Se anota lo curado de verdad, no lo teórico.
            $cura = $hayClerigo ? $sala['valor'] * 2 : $sala['valor'];
            $vidaAntes = $vidaParty;
            $vidaParty = min($vidaParty + $cura, $vidaMaxParty);
            $linea = $etiqueta . ': descanso, +' . ($vidaParty - $vidaAntes) . ' de vida';
            if ($hayClerigo) {
                $linea .= ' (bendición del Clérigo)';
            }
            $diario[] = $linea . '.';
            break;

        default:
            // Un tipo no previsto no debe pasar desapercibido en el informe.
            $diario[] = $etiqueta . ': tipo de sala desconocido («' . $sala['tipo'] . '»).';
    }

    // Si la party cae, la expedición termina aquí: break sale del foreach
    // (estamos fuera del switch, así que basta con un nivel).
    if ($vidaParty <= 0) {
        $vidaParty = 0;
        $diario[] = 'La party cae en la sala ' . $numSala . ': la expedición termina.';
        break;
    }
}
$salasPendientes = count($salas) - $salasExploradas;

// =====================================================================
// R5 · EL JEFE
// =====================================================================
$tieneLlave = array_key_exists($jefe['llave'], $inventario);
$golpe      = (int) round($danioParty);   // el golpe es entero; el daño real es decimal
$vidaJefe   = $jefe['vida'];
$rondas     = [];
$ronda      = 0;

if ($vidaParty <= 0) {
    $resultado = 'Derrota';
    $motivo    = 'la party no llegó con vida hasta el jefe';
} elseif (!$tieneLlave) {
    $resultado = 'Puerta sellada';
    $motivo    = 'falta «' . $jefe['llave'] . '» para entrar';
} else {
    // MAX_RONDAS evita un bucle infinito si el golpe no basta para vencer.
    while ($vidaJefe > 0 && $vidaParty > 0 && $ronda < MAX_RONDAS) {
        $ronda++;
        $vidaJefe = max(0, $vidaJefe - $golpe);
        // El jefe solo contraataca si sigue vivo.
        if ($vidaJefe > 0) {
            $vidaParty = max(0, $vidaParty - $jefe['ataque']);
        }
        $rondas[] = ['ronda' => $ronda, 'vidaJefe' => $vidaJefe, 'vidaParty' => $vidaParty];
    }

    // match(true) permite usar condiciones como brazos; gana la primera cierta.
    $resultado = match (true) {
        $vidaJefe <= 0  => 'Victoria',
        $vidaParty <= 0 => 'Derrota',
        default         => 'Retirada',
    };

    if ($resultado === 'Victoria') {
        $oro += $jefe['recompensa'];
        $motivo = 'en la ronda ' . $ronda . ' · recompensa +' . number_format((float) $jefe['recompensa'], 0, ',', '.') . ' mo';
    } elseif ($resultado === 'Derrota') {
        $motivo = 'la party cae en la ronda ' . $ronda;
    } else {
        $motivo = 'el jefe sigue en pie tras ' . $ronda . ' rondas';
    }
}

// Clase CSS del resultado: verde si se gana, rojo en cualquier otro caso.
$claseResultado = 'peligro';
if ($resultado === 'Victoria') {
    $claseResultado = 'vida';
}

// =====================================================================
// R4 (cont.) · INVENTARIO FINAL
// =====================================================================
// Se calcula después del jefe para incluir los objetos hallados en las salas.
// Los subtotales se guardan aparte para no repetir la multiplicación al pintar.
$valorInventario = 0.0;
$subtotales      = [];
foreach ($inventario as $objeto => $cantidad) {
    $subtotales[$objeto] = $cantidad * ($precios[$objeto] ?? 0.0);
    $valorInventario    += $subtotales[$objeto];
}
$totalObjetos = array_sum($inventario);

// arsort ordena por valor (mayor a menor) conservando las claves; sort las
// perdería y no sabríamos a qué objeto pertenece cada cantidad. Se ordena una
// copia para no alterar el inventario original.
$inventarioOrdenado = $inventario;
arsort($inventarioOrdenado);
$objetoMasAbundante = array_key_first($inventarioOrdenado) ?? '—';

// =====================================================================
// R6 · EL MAPA
// =====================================================================
/* Recorrido por filas y columnas: count() se evalúa en cada fila porque
   el mapa podría tener filas de distinta longitud. */
$conteoCeldas = [];
for ($f = 0; $f < count($mapa); $f++) {
    for ($c = 0; $c < count($mapa[$f]); $c++) {
        $celda = $mapa[$f][$c];
        $conteoCeldas[$celda] = ($conteoCeldas[$celda] ?? 0) + 1;
    }
}
// Cada sala del mapa se marca con 'S': si no coinciden, el mapa o los datos fallan.
$mapaCoherente = ($conteoCeldas['S'] ?? 0) === count($salas);

// Barra final de la party, con la vida tras el combate contra el jefe.
$bloquesFinales = (int) round($vidaParty / $vidaMaxParty * BLOQUES_BARRA);
$barraFinal = '';
for ($b = 0; $b < BLOQUES_BARRA; $b++) {
    if ($b < $bloquesFinales) {
        $barraFinal .= '█';
    } else {
        $barraFinal .= '░';
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Expedición · <?= htmlspecialchars($nombreMazmorra) ?> · Forja de Héroes II</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<main>
    <span class="insignia">VARIANTE <?= htmlspecialchars(VARIANTE) ?></span>
    <h1><?= htmlspecialchars($nombreMazmorra) ?></h1>
    <p class="subtitulo">Informe de expedición · líder: <?= htmlspecialchars($nombreLider) ?></p>

    <h2>La party</h2>
    <table>
        <tr><th>Héroe</th><th>Clase</th><th>Nivel</th><th>Vida</th><th>Daño</th><th>Poder</th><th>Posición</th><th>Estado</th></tr>
        <?php foreach ($party as $heroe): ?>
        <tr><td><?= htmlspecialchars($heroe['nombre']) ?></td>
            <td><?= htmlspecialchars($heroe['clase']) ?></td>
            <td><?= $heroe['nivel'] ?></td>
            <td><span class="barra mini"><?= $heroe['barra'] ?></span> <?= $heroe['vida'] ?>/<?= $heroe['vidaMax'] ?></td>
            <td><?= number_format($heroe['danio'], 1, ',', '.') ?></td>
            <td><?= $heroe['poder'] ?></td>
            <td><?= htmlspecialchars($heroe['posicion']) ?></td>
            <?php if ($heroe['estado'] === 'K.O.' || $heroe['estado'] === 'En peligro'): ?>
            <td class="peligro"><?= htmlspecialchars($heroe['estado']) ?></td>
            <?php else: ?>
            <td class="vida"><?= htmlspecialchars($heroe['estado']) ?></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </table>

    <div class="rejilla">
        <div class="stat"><div class="etq">Poder total</div><div class="val"><?= $poderParty ?></div></div>
        <div class="stat"><div class="etq">Nivel medio</div><div class="val"><?= number_format($nivelMedio, 1, ',', '.') ?></div></div>
        <div class="stat"><div class="etq">Daño por ronda</div><div class="val"><?= number_format($danioParty, 1, ',', '.') ?></div></div>
        <div class="stat"><div class="etq">Héroes activos</div><div class="val"><?= $heroesActivos ?> / <?= count($party) ?></div></div>
    </div>

    <h2>Diario de la expedición</h2>
    <ol class="diario">
        <?php foreach ($diario as $linea): ?>
        <li><?= htmlspecialchars($linea) ?></li>
        <?php endforeach; ?>
    </ol>
    <p>Salas exploradas: <?= $salasExploradas ?> de <?= count($salas) ?>
        <?php if ($salasPendientes > 0): ?>
        · <span class="peligro"><?= $salasPendientes ?> sin explorar</span>
        <?php endif; ?>
        · XP ganada: <?= $xpGanada ?></p>

    <h2>El jefe: <?= htmlspecialchars($jefe['nombre']) ?></h2>
    <p>Vida <?= $jefe['vida'] ?> · ataque <?= $jefe['ataque'] ?> · golpe de la party: <?= $golpe ?> por ronda</p>
    <?php if (count($rondas) > 0): ?>
    <table>
        <tr><th>Ronda</th><th>Vida del jefe</th><th>Vida de la party</th></tr>
        <?php foreach ($rondas as $fila): ?>
        <tr><td><?= $fila['ronda'] ?></td><td><?= $fila['vidaJefe'] ?></td><td><?= $fila['vidaParty'] ?></td></tr>
        <?php endforeach; ?>
    </table>
    <?php endif; ?>
    <p class="resultado <?= $claseResultado ?>"><strong><?= htmlspecialchars($resultado) ?></strong> · <?= htmlspecialchars($motivo) ?></p>
    <p class="barra vida">PARTY <?= $barraFinal ?> <?= $vidaParty ?>/<?= $vidaMaxParty ?></p>

    <h2>Inventario</h2>
    <table>
        <tr><th>Objeto</th><th>Cantidad</th><th>Precio</th><th>Subtotal</th></tr>
        <?php foreach ($inventarioOrdenado as $objeto => $cantidad): ?>
        <tr><td><?= htmlspecialchars((string) $objeto) ?></td>
            <td><?= $cantidad ?></td>
            <td><?= number_format($precios[$objeto] ?? 0.0, 2, ',', '.') ?> mo</td>
            <td><?= number_format($subtotales[$objeto], 2, ',', '.') ?> mo</td></tr>
        <?php endforeach; ?>
    </table>
    <div class="rejilla">
        <div class="stat"><div class="etq">Objetos</div><div class="val"><?= $totalObjetos ?></div></div>
        <div class="stat"><div class="etq">Valor del inventario</div><div class="val"><?= number_format($valorInventario, 2, ',', '.') ?> mo</div></div>
        <div class="stat"><div class="etq">Oro final</div><div class="val"><?= number_format($oro, 2, ',', '.') ?> mo</div></div>
        <div class="stat"><div class="etq">Más abundante</div><div class="val peq"><?= htmlspecialchars((string) $objetoMasAbundante) ?></div></div>
    </div>

    <h2>Mapa de la mazmorra</h2>
    <table class="mapa">
        <?php foreach ($mapa as $fila): ?>
        <tr>
            <?php foreach ($fila as $celda): ?>
            <td class="<?= LEYENDA_MAPA[$celda][0] ?? 'desconocida' ?>"><?= htmlspecialchars((string) $celda) ?></td>
            <?php endforeach; ?>
        </tr>
        <?php endforeach; ?>
    </table>
    <p>
        <?php foreach ($conteoCeldas as $celda => $veces): ?>
        <code><?= htmlspecialchars((string) $celda) ?></code> <?= htmlspecialchars(LEYENDA_MAPA[$celda][1] ?? 'Desconocida') ?>: <?= $veces ?> &nbsp;
        <?php endforeach; ?>
    </p>
    <?php if ($mapaCoherente): ?>
    <p class="vida">✔ El mapa es coherente: <?= $conteoCeldas['S'] ?? 0 ?> salas marcadas, tantas como salas hay en los datos.</p>
    <?php else: ?>
    <p class="peligro">✘ El mapa no es coherente: muestra <?= $conteoCeldas['S'] ?? 0 ?> salas pero los datos tienen <?= count($salas) ?>.</p>
    <?php endif; ?>

    <footer>Informe generado el <?= date('d/m/Y H:i:s') ?> con PHP <?= PHP_VERSION ?> · cada recarga lo recalcula todo desde cero.</footer>
</main>
</body>
</html>
